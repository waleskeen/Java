package projectcharter;
//Contribute by Chan Chee Keen
public interface Module4calculation 
{
	//function:to implement all of the function into class
	//input:function
	//output:force to use all of the function
    public double calculateTotalBudgetCost();
}
