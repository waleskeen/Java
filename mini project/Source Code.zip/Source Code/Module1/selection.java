package projectcharter;
//Contribute by Ang Fan Yee

import java.util.*;

public class selection {

    public FA F = new FA();
    public List<WSMList> W = new ArrayList();
    public project P = new project();
    public WSM sco=new WSM();
    public YearList Yuser=new YearList();
   
   
}
