package projectcharter;
//Contribute by Ang Fan Yee

public class project {

    private double NPV;
    private double ROI;
    private double IRR;
    private double PAYBACK;
    private double PWSM;
    public double valueNPV;
    public double valueROI;
    public double valueIRR;
    public double valuePAYBACK;
    public double valueWSM;
    public double sumNPV;
    public double sumROI;
    public double sumIRR;
    public double sumPAYBACK;
    public double sumWSM;
    public double totalmark;

    public double getNPV() {
        return NPV;
    }

    public void setNPV(double npv) {
        NPV = npv;
    }

    public double getROI() {
        return ROI;
    }

    public void setROI(double roi) {
        ROI = roi;
    }

    public double getIRR() {
        return IRR;
    }

    public void setIRR(double irr) {
        IRR = irr;
    }

    public double getPAYBACK() {
        return PAYBACK;
    }

    public void setPAYBACK(double payback) {
        PAYBACK = payback;
    }

    public double getPWSM() {
        return PWSM;
    }

    public void setPWSM(double pwsm) {
        PWSM = pwsm;
    }
}
