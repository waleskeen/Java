package projectcharter;
//Contribute By Foong Wai Lap
/**
 *
 * @author Foong Wai Lap
 */

import java.util.*;
/////////////////////////Save subactivity into String////////////////////////////////
public class savestring {

    public String ActivityID;
    public List<savestring> subActivity = new ArrayList();
public String ColumnName;
public String ValueAt;
    public savestring() {
    }
}