/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package projectcharter;

//Contributed by Brenda Lee Hooi Fern

public class ProjectDuration extends ThreePointEstimates{
 public boolean userInputDurationPEst()
 {
     return true;
 }
public void generateDurationGraph()
{
        
}
}
