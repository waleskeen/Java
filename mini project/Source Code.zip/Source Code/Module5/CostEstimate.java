/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package projectcharter;
//Contributed by Brenda Lee Hooi Fern

//class for costestimate
public class CostEstimate extends ThreePointEstimates{
 public boolean userInputCostPEst()
 {
     return true;
 }
 
}
